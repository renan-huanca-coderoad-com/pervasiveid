#!/bin/bash
for i in `seq 1 144`;
do
   node pervasiveid.js
done    
